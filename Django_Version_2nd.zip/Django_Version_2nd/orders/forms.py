from django.forms import ModelForm
from django import forms
from .models import Order

class OrderForm(ModelForm):
    OPTIONS = (
        ('',''),
        #('Postpay','Postpay'),
        #('Prepay (Full)','Prepay (Full)'),
        #('Prepay (Half)', 'Prepay (Half)'),
        ('Cash','Cash'),
        ('CreditCard', 'CreditCard'),
        ('NetBanking', 'NetBanking')
    )
    OPTIONS2 = (
        ('Confirm', 'Confirm'),
        ('Ready', 'Ready'),
        ('Send', 'Send'),
        ('Delivered', 'Delivered'),
        ('Returned', 'Returned'),
        ('Cancelled', 'Cancelled')
    )
    order_status = forms.TypedChoiceField(required=False, choices=OPTIONS2, widget=forms.RadioSelect)
    payment_option = forms.ChoiceField(choices=OPTIONS)

    class Meta:
        model = Order
        fields = ['name','phone','address','email_id','invoice_no','invoice_date','delivery_date','product_id','payment_option','amount','vat','order_status']