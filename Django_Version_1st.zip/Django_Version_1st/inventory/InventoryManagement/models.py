# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from __future__ import unicode_literals

from django.db import models


class BillPayments(models.Model):
    id = models.IntegerField(primary_key=True)
    payment_id = models.IntegerField(blank=True, null=True)
    bill_id = models.IntegerField(blank=True, null=True)
    amount = models.TextField()  # This field type is a guess.
    deleted = models.TextField()  # This field type is a guess.

    class Meta:
        managed = False
        db_table = 'bill_payments'


class BillProducts(models.Model):
    id = models.IntegerField(primary_key=True, unique=True)
    product_id = models.IntegerField(blank=True, null=True)
    invoice_id = models.IntegerField(blank=True, null=True)
    name = models.TextField()  # This field type is a guess.
    description = models.TextField(blank=True, null=True)  # This field type is a guess.
    measuring_unit = models.TextField(blank=True, null=True)  # This field type is a guess.
    price = models.TextField()  # This field type is a guess.
    quantity = models.TextField()  # This field type is a guess.
    has_tax_included = models.NullBooleanField()
    tax_id = models.IntegerField(blank=True, null=True)
    total_no_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_all = models.TextField(blank=True, null=True)  # This field type is a guess.
    is_discount = models.NullBooleanField()
    discount_percentage = models.IntegerField()
    type = models.TextField()  # This field type is a guess.
    sku = models.TextField(blank=True, null=True)  # This field type is a guess.
    purchase_rate = models.TextField(blank=True, null=True)  # This field type is a guess.
    hsn = models.CharField(max_length=30, blank=True, null=True)
    sac = models.CharField(max_length=30, blank=True, null=True)
    
    class Meta:
        managed = False
        db_table = 'bill_products'


class Bills(models.Model):
    id = models.IntegerField(primary_key=True, unique=True)
    number = models.TextField()  # This field type is a guess.
    issue_date = models.TextField()  # This field type is a guess.
    due_date = models.TextField(blank=True, null=True)  # This field type is a guess.
    company_details_id = models.IntegerField(blank=True, null=True)
    client_id = models.IntegerField(blank=True, null=True)
    client_name = models.TextField()  # This field type is a guess.
    client_code = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_email = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_telephone = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_contact = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_billing_address = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_billing_zip = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_billing_city = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_shipping_address = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_shipping_zip = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_shipping_city = models.TextField(blank=True, null=True)  # This field type is a guess.
    is_paid = models.NullBooleanField()
    is_draft = models.NullBooleanField()
    total_no_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_all = models.TextField(blank=True, null=True)  # This field type is a guess.
    internal_notes = models.TextField(blank=True, null=True)  # This field type is a guess.
    invoice_notes = models.TextField(blank=True, null=True)  # This field type is a guess.
    deleted = models.TextField()  # This field type is a guess.
    color = models.TextField()  # This field type is a guess.
    po_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    logo = models.TextField(blank=True, null=True)  # This field type is a guess.
    page_size_id = models.IntegerField(blank=True, null=True)
    client_billing_state_id = models.IntegerField(blank=True, null=True)
    client_shipping_state_id = models.IntegerField(blank=True, null=True)
    pay_email = models.TextField(blank=True, null=True)  # This field type is a guess.
    pay_online = models.NullBooleanField()
    flag_id = models.IntegerField(blank=True, null=True)
    layout = models.IntegerField()
    discount = models.TextField(blank=True, null=True)  # This field type is a guess.
    sent = models.NullBooleanField()
    print_id = models.IntegerField()
    type = models.TextField(blank=True, null=True)  # This field type is a guess.
    fiscal_year = models.TextField(blank=True, null=True)  # This field type is a guess.
    number_prefix = models.TextField(blank=True, null=True)  # This field type is a guess.
    second_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    excise_duty = models.TextField(blank=True, null=True)  # This field type is a guess.
    use_transport = models.NullBooleanField()
    delivery_note = models.TextField(blank=True, null=True)  # This field type is a guess.
    vehicle_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    esugam = models.TextField(blank=True, null=True)  # This field type is a guess.
    lr_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    shipping_method = models.TextField(blank=True, null=True)  # This field type is a guess.
    excise_cess = models.TextField(blank=True, null=True)  # This field type is a guess.
    cancelled = models.NullBooleanField()
    quantity_no_decimal = models.NullBooleanField()
    product_inline_discount = models.NullBooleanField()
    esugam_label = models.IntegerField()
    po_date = models.TextField(blank=True, null=True)  # This field type is a guess.
    gst_type = models.CharField(max_length=5, blank=True, null=True)
    
    class Meta:
        managed = False
        db_table = 'bills'


class Clients(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.TextField()  # This field type is a guess.
    code = models.TextField(blank=True, null=True)  # This field type is a guess.
    email = models.TextField(blank=True, null=True)  # This field type is a guess.
    telephone = models.TextField(blank=True, null=True)  # This field type is a guess.
    contact = models.TextField(blank=True, null=True)  # This field type is a guess.
    billing_address = models.TextField(blank=True, null=True)  # This field type is a guess.
    billing_zip = models.TextField(blank=True, null=True)  # This field type is a guess.
    billing_city = models.TextField(blank=True, null=True)  # This field type is a guess.
    shipping_address = models.TextField(blank=True, null=True)  # This field type is a guess.
    shipping_zip = models.TextField(blank=True, null=True)  # This field type is a guess.
    shipping_city = models.TextField(blank=True, null=True)  # This field type is a guess.
    billing_state_id = models.IntegerField(blank=True, null=True)
    shipping_state_id = models.IntegerField(blank=True, null=True)
    details = models.TextField(blank=True, null=True)  # This field type is a guess.
    details_public = models.TextField(blank=True, null=True)  # This field type is a guess.
    deleted = models.TextField()  # This field type is a guess.
    tin = models.TextField(blank=True, null=True)  # This field type is a guess.
    pan = models.TextField(blank=True, null=True)  # This field type is a guess.
    vat_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    gstin = models.TextField(blank=True, null=True)  # This field type is a guess.

    class Meta:
        managed = False
        db_table = 'clients'



class InvoiceProducts(models.Model):
    id = models.IntegerField(primary_key=True, unique=True)
    product_id = models.IntegerField(blank=True, null=True)
    invoice_id = models.IntegerField(blank=True, null=True)
    name = models.TextField()  # This field type is a guess.
    description = models.TextField(blank=True, null=True)  # This field type is a guess.
    measuring_unit = models.TextField(blank=True, null=True)  # This field type is a guess.
    price = models.TextField()  # This field type is a guess.
    quantity = models.TextField()  # This field type is a guess.
    has_tax_included = models.NullBooleanField()
    tax_id = models.IntegerField(blank=True, null=True)
    total_no_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_all = models.TextField(blank=True, null=True)  # This field type is a guess.
    is_discount = models.NullBooleanField()
    discount_percentage = models.IntegerField()
    type = models.TextField()  # This field type is a guess.
    sku = models.TextField(blank=True, null=True)  # This field type is a guess.
    purchase_rate = models.TextField(blank=True, null=True)  # This field type is a guess.
    hsn = models.CharField(max_length=30, blank=True, null=True)
    sac = models.CharField(max_length=30, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'invoice_products'


class Invoices(models.Model):
    id = models.IntegerField(primary_key=True, unique=True)
    number = models.TextField()  # This field type is a guess.
    issue_date = models.TextField()  # This field type is a guess.
    due_date = models.TextField(blank=True, null=True)  # This field type is a guess.
    company_details_id = models.IntegerField(blank=True, null=True)
    client_id = models.IntegerField(blank=True, null=True)
    client_name = models.TextField()  # This field type is a guess.
    client_code = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_email = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_telephone = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_contact = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_billing_address = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_billing_zip = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_billing_city = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_shipping_address = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_shipping_zip = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_shipping_city = models.TextField(blank=True, null=True)  # This field type is a guess.
    is_paid = models.NullBooleanField()
    is_draft = models.NullBooleanField()
    total_no_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_all = models.TextField(blank=True, null=True)  # This field type is a guess.
    internal_notes = models.TextField(blank=True, null=True)  # This field type is a guess.
    invoice_notes = models.TextField(blank=True, null=True)  # This field type is a guess.
    deleted = models.TextField()  # This field type is a guess.
    color = models.TextField()  # This field type is a guess.
    po_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    logo = models.TextField(blank=True, null=True)  # This field type is a guess.
    page_size_id = models.IntegerField(blank=True, null=True)
    client_billing_state_id = models.IntegerField(blank=True, null=True)
    client_shipping_state_id = models.IntegerField(blank=True, null=True)
    pay_email = models.TextField(blank=True, null=True)  # This field type is a guess.
    pay_online = models.NullBooleanField()
    flag_id = models.IntegerField(blank=True, null=True)
    layout = models.IntegerField()
    discount = models.TextField(blank=True, null=True)  # This field type is a guess.
    sent = models.NullBooleanField()
    print_id = models.IntegerField()
    type = models.TextField(blank=True, null=True)  # This field type is a guess.
    fiscal_year = models.TextField(blank=True, null=True)  # This field type is a guess.
    number_prefix = models.TextField(blank=True, null=True)  # This field type is a guess.
    second_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    excise_duty = models.TextField(blank=True, null=True)  # This field type is a guess.
    use_transport = models.NullBooleanField()
    delivery_note = models.TextField(blank=True, null=True)  # This field type is a guess.
    vehicle_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    esugam = models.TextField(blank=True, null=True)  # This field type is a guess.
    lr_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    shipping_method = models.TextField(blank=True, null=True)  # This field type is a guess.
    excise_cess = models.TextField(blank=True, null=True)  # This field type is a guess.
    cancelled = models.NullBooleanField()
    quantity_no_decimal = models.NullBooleanField()
    product_inline_discount = models.NullBooleanField()
    esugam_label = models.IntegerField()
    po_date = models.TextField(blank=True, null=True)  # This field type is a guess.
    gst_type = models.CharField(max_length=5, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'invoices'



class Products(models.Model):
    id = models.IntegerField(primary_key=True, unique=True)
    name = models.TextField()  # This field type is a guess.
    description = models.TextField(blank=True, null=True)  # This field type is a guess.
    measuring_unit = models.TextField(blank=True, null=True)  # This field type is a guess.
    price = models.TextField()  # This field type is a guess.
    has_tax_included = models.BooleanField()
    tax_id = models.IntegerField(blank=True, null=True)
    deleted = models.TextField()  # This field type is a guess.
    type = models.TextField()  # This field type is a guess.
    sku = models.TextField(blank=True, null=True)  # This field type is a guess.
    purchase_rate = models.TextField(blank=True, null=True)  # This field type is a guess.
    hsn = models.CharField(max_length=30, blank=True, null=True)
    sac = models.CharField(max_length=30, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'products'


class PurchaseOrder(models.Model):
    id = models.IntegerField(primary_key=True, unique=True)
    number = models.TextField()  # This field type is a guess.
    issue_date = models.TextField()  # This field type is a guess.
    due_date = models.TextField(blank=True, null=True)  # This field type is a guess.
    company_details_id = models.IntegerField(blank=True, null=True)
    client_id = models.IntegerField(blank=True, null=True)
    client_name = models.TextField()  # This field type is a guess.
    client_code = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_email = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_telephone = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_contact = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_billing_address = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_billing_zip = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_billing_city = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_shipping_address = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_shipping_zip = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_shipping_city = models.TextField(blank=True, null=True)  # This field type is a guess.
    is_paid = models.NullBooleanField()
    is_draft = models.NullBooleanField()
    total_no_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_all = models.TextField(blank=True, null=True)  # This field type is a guess.
    internal_notes = models.TextField(blank=True, null=True)  # This field type is a guess.
    invoice_notes = models.TextField(blank=True, null=True)  # This field type is a guess.
    deleted = models.TextField()  # This field type is a guess.
    color = models.TextField()  # This field type is a guess.
    po_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    logo = models.TextField(blank=True, null=True)  # This field type is a guess.
    page_size_id = models.IntegerField(blank=True, null=True)
    client_billing_state_id = models.IntegerField(blank=True, null=True)
    client_shipping_state_id = models.IntegerField(blank=True, null=True)
    pay_email = models.TextField(blank=True, null=True)  # This field type is a guess.
    pay_online = models.NullBooleanField()
    flag_id = models.IntegerField(blank=True, null=True)
    layout = models.IntegerField()
    discount = models.TextField(blank=True, null=True)  # This field type is a guess.
    sent = models.NullBooleanField()
    print_id = models.IntegerField()
    type = models.TextField(blank=True, null=True)  # This field type is a guess.
    fiscal_year = models.TextField(blank=True, null=True)  # This field type is a guess.
    number_prefix = models.TextField(blank=True, null=True)  # This field type is a guess.
    second_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    excise_duty = models.TextField(blank=True, null=True)  # This field type is a guess.
    use_transport = models.NullBooleanField()
    delivery_note = models.TextField(blank=True, null=True)  # This field type is a guess.
    vehicle_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    esugam = models.TextField(blank=True, null=True)  # This field type is a guess.
    lr_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    shipping_method = models.TextField(blank=True, null=True)  # This field type is a guess.
    excise_cess = models.TextField(blank=True, null=True)  # This field type is a guess.
    cancelled = models.NullBooleanField()
    quantity_no_decimal = models.NullBooleanField()
    product_inline_discount = models.NullBooleanField()
    esugam_label = models.IntegerField()
    po_date = models.TextField(blank=True, null=True)  # This field type is a guess.
    gst_type = models.CharField(max_length=5, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'purchase_order'



class PurchaseOrderProducts(models.Model):
    id = models.IntegerField(primary_key=True, unique=True)
    product_id = models.IntegerField(blank=True, null=True)
    invoice_id = models.IntegerField(blank=True, null=True)
    name = models.TextField()  # This field type is a guess.
    description = models.TextField(blank=True, null=True)  # This field type is a guess.
    measuring_unit = models.TextField(blank=True, null=True)  # This field type is a guess.
    price = models.TextField()  # This field type is a guess.
    quantity = models.TextField()  # This field type is a guess.
    has_tax_included = models.NullBooleanField()
    tax_id = models.IntegerField(blank=True, null=True)
    total_no_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_all = models.TextField(blank=True, null=True)  # This field type is a guess.
    is_discount = models.NullBooleanField()
    discount_percentage = models.IntegerField()
    type = models.TextField()  # This field type is a guess.
    sku = models.TextField(blank=True, null=True)  # This field type is a guess.
    purchase_rate = models.TextField(blank=True, null=True)  # This field type is a guess.
    hsn = models.CharField(max_length=30, blank=True, null=True)
    sac = models.CharField(max_length=30, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'purchase_order_products'

class QuatationOrder(models.Model):
    id = models.IntegerField(primary_key=True, unique=True)
    number = models.TextField()  # This field type is a guess.
    issue_date = models.TextField()  # This field type is a guess.
    due_date = models.TextField(blank=True, null=True)  # This field type is a guess.
    company_details_id = models.IntegerField(blank=True, null=True)
    client_id = models.IntegerField(blank=True, null=True)
    client_name = models.TextField()  # This field type is a guess.
    client_code = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_email = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_telephone = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_contact = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_billing_address = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_billing_zip = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_billing_city = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_shipping_address = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_shipping_zip = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_shipping_city = models.TextField(blank=True, null=True)  # This field type is a guess.
    is_paid = models.NullBooleanField()
    is_draft = models.NullBooleanField()
    total_no_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_all = models.TextField(blank=True, null=True)  # This field type is a guess.
    internal_notes = models.TextField(blank=True, null=True)  # This field type is a guess.
    invoice_notes = models.TextField(blank=True, null=True)  # This field type is a guess.
    deleted = models.TextField()  # This field type is a guess.
    color = models.TextField()  # This field type is a guess.
    po_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    logo = models.TextField(blank=True, null=True)  # This field type is a guess.
    page_size_id = models.IntegerField(blank=True, null=True)
    client_billing_state_id = models.IntegerField(blank=True, null=True)
    client_shipping_state_id = models.IntegerField(blank=True, null=True)
    pay_email = models.TextField(blank=True, null=True)  # This field type is a guess.
    pay_online = models.NullBooleanField()
    flag_id = models.IntegerField(blank=True, null=True)
    layout = models.IntegerField()
    discount = models.TextField(blank=True, null=True)  # This field type is a guess.
    sent = models.NullBooleanField()
    print_id = models.IntegerField()
    type = models.TextField(blank=True, null=True)  # This field type is a guess.
    fiscal_year = models.TextField(blank=True, null=True)  # This field type is a guess.
    number_prefix = models.TextField(blank=True, null=True)  # This field type is a guess.
    second_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    excise_duty = models.TextField(blank=True, null=True)  # This field type is a guess.
    use_transport = models.NullBooleanField()
    delivery_note = models.TextField(blank=True, null=True)  # This field type is a guess.
    vehicle_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    esugam = models.TextField(blank=True, null=True)  # This field type is a guess.
    lr_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    shipping_method = models.TextField(blank=True, null=True)  # This field type is a guess.
    excise_cess = models.TextField(blank=True, null=True)  # This field type is a guess.
    cancelled = models.NullBooleanField()
    quantity_no_decimal = models.NullBooleanField()
    product_inline_discount = models.NullBooleanField()
    esugam_label = models.IntegerField()
    po_date = models.TextField(blank=True, null=True)  # This field type is a guess.
    gst_type = models.CharField(max_length=5, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'QuatationOrder'




class QuatationOrderProducts(models.Model):
    id = models.IntegerField(primary_key=True, unique=True)
    product_id = models.IntegerField(blank=True, null=True)
    invoice_id = models.IntegerField(blank=True, null=True)
    name = models.TextField()  # This field type is a guess.
    description = models.TextField(blank=True, null=True)  # This field type is a guess.
    measuring_unit = models.TextField(blank=True, null=True)  # This field type is a guess.
    price = models.TextField()  # This field type is a guess.
    quantity = models.TextField()  # This field type is a guess.
    has_tax_included = models.NullBooleanField()
    tax_id = models.IntegerField(blank=True, null=True)
    total_no_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_all = models.TextField(blank=True, null=True)  # This field type is a guess.
    is_discount = models.NullBooleanField()
    discount_percentage = models.IntegerField()
    type = models.TextField()  # This field type is a guess.
    sku = models.TextField(blank=True, null=True)  # This field type is a guess.
    purchase_rate = models.TextField(blank=True, null=True)  # This field type is a guess.
    hsn = models.CharField(max_length=30, blank=True, null=True)
    sac = models.CharField(max_length=30, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'QuatationOrderProducts'
		
class GrnData(models.Model):
    id = models.IntegerField(primary_key=True, unique=True)
    number = models.TextField()  # This field type is a guess.
    issue_date = models.TextField()  # This field type is a guess.
    due_date = models.TextField(blank=True, null=True)  # This field type is a guess.
    company_details_id = models.IntegerField(blank=True, null=True)
    client_id = models.IntegerField(blank=True, null=True)
    client_name = models.TextField()  # This field type is a guess.
    client_code = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_email = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_telephone = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_contact = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_billing_address = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_billing_zip = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_billing_city = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_shipping_address = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_shipping_zip = models.TextField(blank=True, null=True)  # This field type is a guess.
    client_shipping_city = models.TextField(blank=True, null=True)  # This field type is a guess.
    is_paid = models.NullBooleanField()
    is_draft = models.NullBooleanField()
    total_no_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_all = models.TextField(blank=True, null=True)  # This field type is a guess.
    internal_notes = models.TextField(blank=True, null=True)  # This field type is a guess.
    invoice_notes = models.TextField(blank=True, null=True)  # This field type is a guess.
    deleted = models.TextField()  # This field type is a guess.
    color = models.TextField()  # This field type is a guess.
    po_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    logo = models.TextField(blank=True, null=True)  # This field type is a guess.
    page_size_id = models.IntegerField(blank=True, null=True)
    client_billing_state_id = models.IntegerField(blank=True, null=True)
    client_shipping_state_id = models.IntegerField(blank=True, null=True)
    pay_email = models.TextField(blank=True, null=True)  # This field type is a guess.
    pay_online = models.NullBooleanField()
    flag_id = models.IntegerField(blank=True, null=True)
    layout = models.IntegerField()
    discount = models.TextField(blank=True, null=True)  # This field type is a guess.
    sent = models.NullBooleanField()
    print_id = models.IntegerField()
    type = models.TextField(blank=True, null=True)  # This field type is a guess.
    fiscal_year = models.TextField(blank=True, null=True)  # This field type is a guess.
    number_prefix = models.TextField(blank=True, null=True)  # This field type is a guess.
    second_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    excise_duty = models.TextField(blank=True, null=True)  # This field type is a guess.
    use_transport = models.NullBooleanField()
    delivery_note = models.TextField(blank=True, null=True)  # This field type is a guess.
    vehicle_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    esugam = models.TextField(blank=True, null=True)  # This field type is a guess.
    lr_number = models.TextField(blank=True, null=True)  # This field type is a guess.
    shipping_method = models.TextField(blank=True, null=True)  # This field type is a guess.
    excise_cess = models.TextField(blank=True, null=True)  # This field type is a guess.
    cancelled = models.NullBooleanField()
    quantity_no_decimal = models.NullBooleanField()
    product_inline_discount = models.NullBooleanField()
    esugam_label = models.IntegerField()
    po_date = models.TextField(blank=True, null=True)  # This field type is a guess.
    gst_type = models.CharField(max_length=5, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'GrnData'
		
class GrnProducts(models.Model):
    id = models.IntegerField(primary_key=True, unique=True)
    product_id = models.IntegerField(blank=True, null=True)
    invoice_id = models.IntegerField(blank=True, null=True)
    name = models.TextField()  # This field type is a guess.
    description = models.TextField(blank=True, null=True)  # This field type is a guess.
    measuring_unit = models.TextField(blank=True, null=True)  # This field type is a guess.
    price = models.TextField()  # This field type is a guess.
    quantity = models.TextField()  # This field type is a guess.
    has_tax_included = models.NullBooleanField()
    tax_id = models.IntegerField(blank=True, null=True)
    total_no_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_tax = models.TextField(blank=True, null=True)  # This field type is a guess.
    total_all = models.TextField(blank=True, null=True)  # This field type is a guess.
    is_discount = models.NullBooleanField()
    discount_percentage = models.IntegerField()
    type = models.TextField()  # This field type is a guess.
    sku = models.TextField(blank=True, null=True)  # This field type is a guess.
    purchase_rate = models.TextField(blank=True, null=True)  # This field type is a guess.
    hsn = models.CharField(max_length=30, blank=True, null=True)
    sac = models.CharField(max_length=30, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'GrnProducts'