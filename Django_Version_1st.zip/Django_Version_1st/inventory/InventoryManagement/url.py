from django.conf.urls import url
from . import views

#create URL patterns here
urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^GrnDatap$',views.GrnDatap, name='GrnDatap'),
    url(r'^searchq$',views.searchq, name='searchq'),
    url(r'^GrnProductsp$',views.GrnProductsp,name='GrnProductsp'),
    url(r'^invoice$', views.invoice, name='invoice'),
    url(r'^invoicep$', views.invoicepreview, name='invoicep'),
    url(r'^order$', views.order, name='order'),
    url(r'^orderp$', views.orderp, name='orderp'),
    url(r'^quatation$', views.quatation, name='quatation'),
    url(r'^quatationp$', views.quatationp, name='quatationp'),
    url(r'^quatationp$id', views.quatationp, name='quatationp'),
    url(r'^delivarychallan$', views.delivarychallan, name='delivarychallan'),
    url(r'^delivarychallanp$', views.delivarychallanp, name='delivarychallanp'),
    url(r'^clients$', views.clients, name='clients'),
    url(r'^products$', views.products, name='products'),
    url(r'^get_item_details$', views.get_item_details, name="get_item_details")
    ]
