from django.shortcuts import render, redirect, render_to_response
from .models import Clients
from django.http import JsonResponse
from InventoryManagement.models import Products, Invoices, InvoiceProducts, Clients, PurchaseOrder, PurchaseOrderProducts, QuatationOrder, QuatationOrderProducts, BillProducts, Bills, GrnData, GrnProducts
from .forms import InvoiceForm, ClientsForm, ProductsForm, GrnForm, QuotationForm, BillForm, OrderForm

# Create your views here.
def index(request):
    return render(request, 'template/index.html')


def invoice(request):
    if(request.method == "POST"):
        print("")
    elif(request.method == "GET"):
        invoiceno = Invoices.objects.all()
        if(invoiceno.count() <= 0):
            newnum = 1
        else:
            invoiceno = Invoices.objects.all().order_by("-id")[0]
            newnum = invoiceno.id + 1        
        all_clients = Clients.objects.values("id","name", "billing_address")
        all_products = Products.objects.values("id","name", "price")
        return render(request, 'template/invoice.html', {'clients':all_clients, 'products': all_products, 'innumber':newnum})
    else:
        print("Not found")
    return render(request, 'template/invoice.html')

def order(request):
    if(request.method == "POST"):
        print("")
    elif(request.method == "GET"):
        invoiceno = PurchaseOrder.objects.all()
        if(invoiceno.count() <= 0):
            newnum = 1
        else:
            invoiceno = PurchaseOrder.objects.all().order_by("-id")[0]
            newnum = invoiceno.id + 1
        all_clients = Clients.objects.values("id","name", "billing_address")
        all_products = Products.objects.values("id","name", "price")
        return render(request, 'template/order.html', {'clients':all_clients, 'products': all_products, 'innumber':newnum})
    else:
        print("Not found")
    return render(request, 'template/order.html')
	
def GrnDatap(request):
    if(request.method == "POST"):
        print("")
    elif(request.method == "GET"):
        invoiceno = GrnData.objects.all()
        if(invoiceno.count() <= 0):
            newnum = 1
        else:
            invoiceno = GrnData.objects.all().order_by("-id")[0]
            newnum = invoiceno.id + 1
        all_clients = Clients.objects.values("id","name", "billing_address")
        all_products = Products.objects.values("id","name", "price")
        return render(request, 'template/GrnDatap.html', {'clients':all_clients, 'products': all_products, 'innumber':newnum})
    else:
        print("Not found")
    return render(request, 'template/GrnDatap.html')
	
	
def GrnProductsp(request):
    tabledata = []
    maxtax = 0
    data = request.POST
    if(request.method == "POST"):
        invform = GrnForm(request.POST)
        if (invform.is_valid()):
            invform.clientname = invform.cleaned_data["clientname"]
            invform.clients = invform.cleaned_data["clients"]
            invform.invoiceno = invform.cleaned_data["invoiceno"]
            invform.invoicedate = invform.cleaned_data["invoicedate"]
            invform.duedate = invform.cleaned_data["duedate"]
           
            
            
            invform.subtotal = invform.cleaned_data["subtotal"]
            invform.taxtotal = invform.cleaned_data["taxtotal"]
            invform.disctotal = invform.cleaned_data["disctotal"]
            invform.total = invform.cleaned_data["total"]
            invform.ctaxtotal = request.POST.getlist("cgst")
            invform.staxtotal = request.POST.getlist("sgst")
            
            try:
                oInvoice = GrnData.objects.get(number=invform.invoiceno)
            except GrnData.DoesNotExist:
                oInvoice = GrnData()
                
            oInvoice.number = invform.invoiceno
            oInvoice.due_date = invform.duedate
            oInvoice.issue_date = invform.invoicedate
            oInvoice.total_tax = invform.taxtotal
            oInvoice.total_all = invform.total
            oInvoice.total_no_tax = invform.subtotal
            oInvoice.discount = invform.disctotal
            oInvoice.client_id = invform.clients
            oInvoice.client_name = invform.clientname
            oInvoice.layout = 1
            oInvoice.print_id = 0
            oInvoice.esugam_label = 0
            oInvoice.save()
            
            invform.itemid = request.POST.getlist("itemname") #comma sepreted value
            invform.itemname = request.POST.getlist("hdnitemname") #comma sepreted value
            invform.hsn = request.POST.getlist("hsn")
            invform.unit = request.POST.getlist("unit") 
            invform.qty = request.POST.getlist("qty")            
            invform.price = request.POST.getlist("price")
            invform.disc = request.POST.getlist("disc")
            invform.gst = request.POST.getlist("gst")
            invform.itemtotal = request.POST.getlist("itemtotal")
            
            maxtax = round(int(max(invform.gst)) /2) 
            
            for idx, val in enumerate(invform.itemid):
                try:
                    oInvProd = GrnProducts.objects.get(invoice_id=invform.invoiceno, product_id=val)
                except GrnProducts.DoesNotExist:
                    oInvProd = GrnProducts()
                    
                oInvProd.product_id = val
                oInvProd.invoice_id = invform.invoiceno
                oInvProd.name = invform.itemname[idx]
                oInvProd.hsn = invform.hsn[idx] if invform.hsn[idx] != '' else 0 
                oInvProd.quantity = invform.qty[idx] if invform.qty[idx] != '' else 1
                oInvProd.measuring_unit = invform.unit[idx] if invform.unit[idx] != '' else 0
                oInvProd.price = invform.price[idx]
                oInvProd.discount_percentage = invform.disc[idx] if invform.disc[idx] != '' else 0
                oInvProd.tax_id = invform.gst[idx]
                oInvProd.total_all = invform.itemtotal[idx]
                tabledata.append(oInvProd)
                oInvProd.save()
				
            
            return render_to_response("template/GrnProductsp.html", {"form":data, "tbl":tabledata, "tax":maxtax})
        else:
            print("")    
    return render(request, "template/GrnProductsp.html")

def quatation(request):
    if(request.method == "POST"):
        print("")
    elif(request.method == "GET"):
        invoiceno = QuatationOrder.objects.all()
        if(invoiceno.count() <= 0):
            newnum = 1
        else:
            invoiceno = QuatationOrder.objects.all().order_by("-id")[0]
            newnum = invoiceno.id + 1        
        all_clients = Clients.objects.values("id","name", "billing_address")
        all_products = Products.objects.values("id","name", "price")
        return render(request, 'template/quatation.html', {'clients':all_clients, 'products': all_products, 'innumber':newnum})
    else:
        print("Not found")
    return render(request, 'template/quatation.html')

def delivarychallan(request):
    if(request.method == "POST"):
        print("")
    elif(request.method == "GET"):
        invoiceno = Bills.objects.all()
        if(invoiceno.count() <= 0):
            newnum = 1
        else:
            invoiceno = Bills.objects.all().order_by("-id")[0]
            newnum = invoiceno.id + 1
        
        all_clients = Clients.objects.values("id","name", "billing_address")
        all_products = Products.objects.values("id","name", "price")
        return render(request, 'template/delivarychallan.html', {'clients':all_clients, 'products': all_products, 'innumber':newnum})
    else:
        print("Not found")
    return render(request, 'template/delivarychallan.html')

def invoicepreview(request):
    tabledata = []
    maxtax = 0
    data = request.POST
    if(request.method == "POST"):
        invform = InvoiceForm(request.POST)
        if (invform.is_valid()):
            invform.clientname = invform.cleaned_data["clientname"]
            invform.clients = invform.cleaned_data["clients"]
            invform.invoiceno = invform.cleaned_data["invoiceno"]
            invform.invoicedate = invform.cleaned_data["invoicedate"]
            invform.duedate = invform.cleaned_data["duedate"]
           
            
            
            invform.subtotal = invform.cleaned_data["subtotal"]
            invform.taxtotal = invform.cleaned_data["taxtotal"]
            invform.disctotal = invform.cleaned_data["disctotal"]
            invform.total = invform.cleaned_data["total"]
            invform.ctaxtotal = request.POST.getlist("cgst")
            invform.staxtotal = request.POST.getlist("sgst")
            
            try:
                oInvoice = Invoices.objects.get(number=invform.invoiceno)
            except Invoices.DoesNotExist:
                oInvoice = Invoices()
                
            oInvoice.number = invform.invoiceno
            oInvoice.due_date = invform.duedate
            oInvoice.issue_date = invform.invoicedate
            oInvoice.total_tax = invform.taxtotal
            oInvoice.total_all = invform.total
            oInvoice.total_no_tax = invform.subtotal
            oInvoice.discount = invform.disctotal
            oInvoice.client_id = invform.clients
            oInvoice.client_name = invform.clientname
            oInvoice.layout = 1
            oInvoice.print_id = 0
            oInvoice.esugam_label = 0
            oInvoice.save()
            
            invform.itemid = request.POST.getlist("itemname") #comma sepreted value
            invform.itemname = request.POST.getlist("hdnitemname") #comma sepreted value
            invform.hsn = request.POST.getlist("hsn")
            invform.unit = request.POST.getlist("unit") 
            invform.qty = request.POST.getlist("qty")            
            invform.price = request.POST.getlist("price")
            invform.disc = request.POST.getlist("disc")
            invform.gst = request.POST.getlist("gst")
            invform.itemtotal = request.POST.getlist("itemtotal")
            
            maxtax = round(int(max(invform.gst)) /2) 
            
            for idx, val in enumerate(invform.itemid):
                try:
                    oInvProd = InvoiceProducts.objects.get(invoice_id=invform.invoiceno, product_id=val)
                except InvoiceProducts.DoesNotExist:
                    oInvProd = InvoiceProducts()
                    
                oInvProd.product_id = val
                oInvProd.invoice_id = invform.invoiceno
                oInvProd.name = invform.itemname[idx]
                oInvProd.hsn = invform.hsn[idx] if invform.hsn[idx] != '' else 0 
                oInvProd.quantity = invform.qty[idx] if invform.qty[idx] != '' else 1
                oInvProd.measuring_unit = invform.unit[idx] if invform.unit[idx] != '' else 0
                oInvProd.price = invform.price[idx]
                oInvProd.discount_percentage = invform.disc[idx] if invform.disc[idx] != '' else 0
                oInvProd.tax_id = invform.gst[idx]
                oInvProd.total_all = invform.itemtotal[idx]
                tabledata.append(oInvProd)
                oInvProd.save()
            url = "template/invoicepreview.html"
            if 'btn_deliver' in request.POST:
                url = "template/delivarychallanp.html"
            
            return render_to_response(url, {"form":data, "tbl":tabledata, "tax":maxtax})
        else:
            print("")    
    return render(request, "template/invoicepreview.html")

def orderp(request):
    tabledata = []
    maxtax = 0
    data = request.POST
    if(request.method == "POST"):
        invform = OrderForm(request.POST)
        if (invform.is_valid()):
            invform.clientname = invform.cleaned_data["clientname"]
            invform.clients = invform.cleaned_data["clients"]
            invform.invoiceno = invform.cleaned_data["invoiceno"]
            invform.invoicedate = invform.cleaned_data["invoicedate"]
            invform.duedate = invform.cleaned_data["duedate"]
           
            
            
            invform.subtotal = invform.cleaned_data["subtotal"]
            invform.taxtotal = invform.cleaned_data["taxtotal"]
            invform.disctotal = invform.cleaned_data["disctotal"]
            invform.total = invform.cleaned_data["total"]
            invform.ctaxtotal = request.POST.getlist("cgst")
            invform.staxtotal = request.POST.getlist("sgst")
            
            try:
                oInvoice = PurchaseOrder.objects.get(number=invform.invoiceno)
            except PurchaseOrder.DoesNotExist:
                oInvoice = PurchaseOrder()
                
            oInvoice.number = invform.invoiceno
            oInvoice.due_date = invform.duedate
            oInvoice.issue_date = invform.invoicedate
            oInvoice.total_tax = invform.taxtotal
            oInvoice.total_all = invform.total
            oInvoice.total_no_tax = invform.subtotal
            oInvoice.discount = invform.disctotal
            oInvoice.client_id = invform.clients
            oInvoice.client_name = invform.clientname
            oInvoice.layout = 1
            oInvoice.print_id = 0
            oInvoice.esugam_label = 0
            oInvoice.save()
            
            invform.itemid = request.POST.getlist("itemname") #comma sepreted value
            invform.itemname = request.POST.getlist("hdnitemname") #comma sepreted value
            invform.hsn = request.POST.getlist("hsn")
            invform.unit = request.POST.getlist("unit") 
            invform.qty = request.POST.getlist("qty")            
            invform.price = request.POST.getlist("price")
            invform.disc = request.POST.getlist("disc")
            invform.gst = request.POST.getlist("gst")
            invform.itemtotal = request.POST.getlist("itemtotal")
            
            maxtax = round(int(max(invform.gst)) /2) 
            
            for idx, val in enumerate(invform.itemid):
                try:
                    oInvProd = PurchaseOrderProducts.objects.get(invoice_id=invform.invoiceno, product_id=val)
                except PurchaseOrderProducts.DoesNotExist:
                    oInvProd = PurchaseOrderProducts()
                    
                oInvProd.product_id = val
                oInvProd.invoice_id = invform.invoiceno
                oInvProd.name = invform.itemname[idx]
                oInvProd.hsn = invform.hsn[idx] if invform.hsn[idx] != '' else 0 
                oInvProd.quantity = invform.qty[idx] if invform.qty[idx] != '' else 1
                oInvProd.measuring_unit = invform.unit[idx] if invform.unit[idx] != '' else 0
                oInvProd.price = invform.price[idx]
                oInvProd.discount_percentage = invform.disc[idx] if invform.disc[idx] != '' else 0
                oInvProd.tax_id = invform.gst[idx]
                oInvProd.total_all = invform.itemtotal[idx]
                tabledata.append(oInvProd)
                oInvProd.save()
            
            url = "template/orderp.html"
            if 'btninv' in request.POST:
                url = "template/invoicepreview.html"
            
            return render_to_response(url, {"form":data, "tbl":tabledata, "tax":maxtax})
        else:
            print("")
    return render(request, "template/orderp.html")


def quatationp(request):
    tabledata = []
    maxtax = 0
    data = request.POST
    if(request.method == "POST"):
        invform = QuotationForm(request.POST)
        if (invform.is_valid()):
            invform.clientname = invform.cleaned_data["clientname"]
            invform.clients = invform.cleaned_data["clients"]
            invform.invoiceno = invform.cleaned_data["invoiceno"]
            invform.invoicedate = invform.cleaned_data["invoicedate"]
            invform.duedate = invform.cleaned_data["duedate"]
           
            
            
            invform.subtotal = invform.cleaned_data["subtotal"]
            invform.taxtotal = invform.cleaned_data["taxtotal"]
            invform.disctotal = invform.cleaned_data["disctotal"]
            invform.total = invform.cleaned_data["total"]
            invform.ctaxtotal = request.POST.getlist("cgst")
            invform.staxtotal = request.POST.getlist("sgst")
            
            try:
                oInvoice = QuatationOrder.objects.get(number=invform.invoiceno)
            except QuatationOrder.DoesNotExist:
                oInvoice = QuatationOrder()
                
            oInvoice.number = invform.invoiceno
            oInvoice.due_date = invform.duedate
            oInvoice.issue_date = invform.invoicedate
            oInvoice.total_tax = invform.taxtotal
            oInvoice.total_all = invform.total
            oInvoice.total_no_tax = invform.subtotal
            oInvoice.discount = invform.disctotal
            oInvoice.client_id = invform.clients
            oInvoice.client_name = invform.clientname
            oInvoice.layout = 1
            oInvoice.print_id = 0
            oInvoice.esugam_label = 0
            oInvoice.save()
            
            invform.itemid = request.POST.getlist("itemname") #comma sepreted value
            invform.itemname = request.POST.getlist("hdnitemname") #comma sepreted value
            invform.hsn = request.POST.getlist("hsn")
            invform.unit = request.POST.getlist("unit") 
            invform.qty = request.POST.getlist("qty")            
            invform.price = request.POST.getlist("price")
            invform.disc = request.POST.getlist("disc")
            invform.gst = request.POST.getlist("gst")
            invform.itemtotal = request.POST.getlist("itemtotal")
            
            maxtax = round(int(max(invform.gst)) /2) 
            
            for idx, val in enumerate(invform.itemid):
                try:
                    oInvProd = QuatationOrderProducts.objects.get(invoice_id=invform.invoiceno, product_id=val)
                except QuatationOrderProducts.DoesNotExist:
                    oInvProd = QuatationOrderProducts()
                    
                oInvProd.product_id = val
                oInvProd.invoice_id = invform.invoiceno
                oInvProd.name = invform.itemname[idx]
                oInvProd.hsn = invform.hsn[idx] if invform.hsn[idx] != '' else 0 
                oInvProd.quantity = invform.qty[idx] if invform.qty[idx] != '' else 1
                oInvProd.measuring_unit = invform.unit[idx] if invform.unit[idx] != '' else 0
                oInvProd.price = invform.price[idx]
                oInvProd.discount_percentage = invform.disc[idx] if invform.disc[idx] != '' else 0
                oInvProd.tax_id = invform.gst[idx]
                oInvProd.total_all = invform.itemtotal[idx]
                tabledata.append(oInvProd)
                oInvProd.save()
            url = "template/quatationp.html"
            if 'btnorder' in request.POST:
                url = "template/orderp.html"
            
            return render_to_response(url,{"form":data, "tbl":tabledata, "tax":maxtax})
        else:
            print("form is not valid...")           
    else:
        if(request.method == "GET"):
            qnum = request.GET.get("id")
            results = QuatationOrder.objects.filter(id=qnum)
            #maxtax = round(int(max(results[0].gst)) /2)
            oQuaProd = QuatationOrderProducts.objects.get(invoice_id=results[0].number)
            tabledata.append(oQuaProd)
            return render_to_response("template/quatationp.html",{"form":results, "tbl":tabledata, "tax":maxtax})                
        else:
            print("bad request") 

def delivarychallanp(request):
    tabledata = []
    maxtax = 0
    data = request.POST
    if(request.method == "POST"):
        invform = InvoiceForm(request.POST)
        if (invform.is_valid()):
            invform.clientname = invform.cleaned_data["clientname"]
            invform.clients = invform.cleaned_data["clients"]
            invform.invoiceno = invform.cleaned_data["invoiceno"]
            invform.invoicedate = invform.cleaned_data["invoicedate"]
            invform.duedate = invform.cleaned_data["duedate"]
           
            
            
            invform.subtotal = invform.cleaned_data["subtotal"]
            invform.taxtotal = invform.cleaned_data["taxtotal"]
            invform.disctotal = invform.cleaned_data["disctotal"]
            invform.total = invform.cleaned_data["total"]
            invform.ctaxtotal = request.POST.getlist("cgst")
            invform.staxtotal = request.POST.getlist("sgst")
            
            try:
                oInvoice = Bills.objects.get(number=invform.invoiceno)
            except Bills.DoesNotExist:
                oInvoice = Bills()
                
            oInvoice.number = invform.invoiceno
            oInvoice.due_date = invform.duedate
            oInvoice.issue_date = invform.invoicedate
            oInvoice.total_tax = invform.taxtotal
            oInvoice.total_all = invform.total
            oInvoice.total_no_tax = invform.subtotal
            oInvoice.discount = invform.disctotal
            oInvoice.client_id = invform.clients
            oInvoice.client_name = invform.clientname
            oInvoice.layout = 1
            oInvoice.print_id = 0
            oInvoice.esugam_label = 0
            oInvoice.save()
            
            invform.itemid = request.POST.getlist("itemname") #comma sepreted value
            invform.itemname = request.POST.getlist("hdnitemname") #comma sepreted value
            invform.hsn = request.POST.getlist("hsn")
            invform.unit = request.POST.getlist("unit") 
            invform.qty = request.POST.getlist("qty")            
            invform.price = request.POST.getlist("price")
            invform.disc = request.POST.getlist("disc")
            invform.gst = request.POST.getlist("gst")
            invform.itemtotal = request.POST.getlist("itemtotal")
            
            maxtax = round(int(max(invform.gst)) /2) 
            
            for idx, val in enumerate(invform.itemid):
                try:
                    oInvProd = BillProducts.objects.get(invoice_id=invform.invoiceno, product_id=val)
                except BillProducts.DoesNotExist:
                    oInvProd = BillProducts()
                    
                oInvProd.product_id = val
                oInvProd.invoice_id = invform.invoiceno
                oInvProd.name = invform.itemname[idx]
                oInvProd.hsn = invform.hsn[idx] if invform.hsn[idx] != '' else 0 
                oInvProd.quantity = invform.qty[idx] if invform.qty[idx] != '' else 1
                oInvProd.measuring_unit = invform.unit[idx] if invform.unit[idx] != '' else 0
                oInvProd.price = invform.price[idx]
                oInvProd.discount_percentage = invform.disc[idx] if invform.disc[idx] != '' else 0
                oInvProd.tax_id = invform.gst[idx]
                oInvProd.total_all = invform.itemtotal[idx]
                tabledata.append(oInvProd)
                oInvProd.save()
            
            return render_to_response("template/delivarychallanp.html", {"form":data, "tbl":tabledata, "tax":maxtax})
        else:
            print("")
    return render(request, "template/delivarychallanp.html")

def get_item_details(request):
    itemid = request.GET.get('itemid', None)
    data = {'price': getpricebyid(itemid)}
    return JsonResponse(data)

def getpricebyid(itemid):
    data = Products.objects.filter(id=itemid).values_list('price',flat=True)[0]
    return data

def clients(request):
    if(request.method == "POST"):
        oformClient =  ClientsForm(request.POST)
        if(oformClient.is_valid()):
            oformClient.clientname = oformClient.cleaned_data["clientname"]
            oformClient.billto = oformClient.cleaned_data["billto"]
            #oformClient.shipto = oformClient.cleaned_data["shipto"]
            oformClient.contactnum = oformClient.cleaned_data["contactnum"]
            #oformClient.issame = oformClient.cleaned_data["issame"]
            oformClient.email = oformClient.cleaned_data["email"]
            
            
            oClient = Clients()
            oClient.name = oformClient.clientname
            oClient.billing_address = oformClient.billto
            #oClient.shipping_address = oformClient.shipto
            oClient.contact = oformClient.contactnum
            oClient.email = oformClient.email
            oClient.save()
        else:
            print("error in validation")
    else:
        print()
    return render(request, 'template/clients.html')

def products(request):
    if(request.method == "POST"):
        oformProd = ProductsForm(request.POST)
        if(oformProd.is_valid()):
            oformProd.productname = oformProd.cleaned_data["productname"]
            oformProd.tax = oformProd.cleaned_data["tax"]
            oformProd.unit = oformProd.cleaned_data["unit"]
            oformProd.hsn = oformProd.cleaned_data["hsn"]
            oformProd.price = oformProd.cleaned_data["price"]
            
            oProd = Products()
            oProd.name = oformProd.productname
            oProd.measuring_unit = oformProd.unit
            oProd.hsn = oformProd.hsn
            oProd.tax_id = oformProd.tax
            oProd.price = oformProd.price
            oProd.has_tax_included = True           
            oProd.save();
            
        else:
            print("error in validation")
    else:
        print()
    return render(request, 'template/products.html')
	
	
def searchq(request):
    tabledata = []
    maxtax = 0
    data = request.POST
    if request.method == 'POST':
        q = request.POST.get('q')
        opts = request.POST.get('opt')
        if q and opts:
            if opts == 'quotation':
                results = QuatationOrder.objects.filter(id=q)
                return render(request, "template/search.html", {"res": results})
                
            elif opts == 'order':
                form = PurchaseOrderProducts.objects.filter(id=q)                
                return render(request, 'template/orderp.html', {'form':form, 'data':data})				
            elif opts == 'invoice':
                data = Invoices.objects.filter(id=q)
                context = {"form":data, "tbl":tabledata, "tax":maxtax, }
                return render(request, 'template/invoicepreview.html', context_instance=RequestContext(request))				
            elif opts == 'delivery':
                data = Bills.objects.filter(id=q) 
                context = {"form":data, "tbl":tabledata, "tax":maxtax}
                return render(request, 'template/delivarychallanp.html', context_instance=RequestContext(request))
			
    return render(request, 'template/searchq.html', context_instance=RequestContext(request))